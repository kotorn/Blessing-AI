# Change log

## 2.0.0 - 2025-07-28

- Rewrote binance-cli in Rust

### Added (11)

- `alpha full-depth` (`GET /bapi/defi/v1/public/alpha-trade/fullDepth`)
- `derivatives-trading-options tradfi-options-contract` (`POST /eapi/v1/stock/contract`)
- `margin-trading query-liquidation-loan-repay-history` (`GET /sapi/v1/margin/liquidation-loan/repay-history`)
- `margin-trading query-liquidation-loan` (`GET /sapi/v1/margin/liquidation-loan`)
- `margin-trading liquidation-loan-repay` (`POST /sapi/v1/margin/exit-special-key-mode/sapi/v1/margin/liquidation-loan/repay`)
- `sub-account modify-sub-account-api-key-permission` (`POST /sapi/v1/sub-account/subAccountApiPermission`)
- `sub-account delete-sub-account-api-key` (`DELETE /sapi/v1/sub-account/subAccountApi`)
- `sub-account query-sub-account-api-key` (`GET /sapi/v1/sub-account/subAccountApi`)
- `sub-account create-sub-account-api-key` (`POST /sapi/v1/sub-account/subAccountApi`)
- `vip-loan get-viploan-repayment-history` (`GET /sapi/v1/loan/vip/repay/history`)
- `vip-loan query-viploan-fixed-rate-market` (`GET /sapi/v1/loan/vip/fixed/market`)
- `vip-loan vip-loan-fixed-rate-borrow` (`POST /sapi/v1/loan/vip/fixed/borrow`)
- Added W3W Prediction API collection of endpoints.

### Removed (1)

- `check-collateral-repay-rate-stable-rate` `GET /sapi/v1/loan/repay/collateral/rate`


## 1.3.0 - 2026-06-04

**Derivatives Trading Usds Futures**

**Simple Earn**

### Added (1)

- `get-yield-arena-activities` (`GET /sapi/v1/earn/arena/activities`)

**Wallet**

### Added (2)

- `get-country-list` (`GET /sapi/v1/localentity/country/list`)
- `get-region-list` (`GET /sapi/v1/localentity/region/list`)

### Changed (1)

- Added parameter `accountType`
  - affected methods:
    - `dust-convert` (`POST /sapi/v1/asset/dust-convert/convert`)
    - `dust-convertible-assets` (`POST /sapi/v1/asset/dust-convert/query-convertible-assets`)

## 1.2.0 - 2026-05-18

- Added WebSocket streams commands.
- Show short description by default, use "--full-description" to show the full one.

**Derivatives Trading Portfolio Margin**

### Added (7)

- `cancel-all-um-algo-open-orders` (`DELETE /papi/v1/um/algo/allOpenOrders`)
- `cancel-um-algo-order` (`DELETE /papi/v1/um/algo/order`)
- `futures-tradfi-perps-contract` (`POST /papi/v1/um/stock/contract`)
- `new-um-algo-order` (`POST /papi/v1/um/algo/order`)
- `query-all-current-um-open-algo-orders` (`GET /papi/v1/um/algo/openAlgoOrders`)
- `query-current-um-open-algo-order` (`GET /papi/v1/um/algo/algoOrder`)
- `query-um-algo-order-history` (`GET /papi/v1/um/algo/allAlgoOrders`)

**Derivatives Trading Portfolio Margin Pro**

### Added (3)

- `delete-margin-call-level` (`DELETE /sapi/v1/portfolio/margin-call-level`)
- `get-margin-call-level` (`GET /sapi/v1/portfolio/margin-call-level`)
- `set-margin-call-level` (`POST /sapi/v1/portfolio/margin-call-level`)

**Derivatives Trading Usds Futures**

### Changed (3)

- Deleted parameter `page`
  - affected methods:
    - `query-all-algo-orders` (`GET /fapi/v1/allAlgoOrders`)
- Modified parameter `interval`:
  - enum added: `1s`
  - affected methods:
    - `continuous-contract-kline-candlestick-data` (`GET /fapi/v1/continuousKlines`)
    - `index-price-kline-candlestick-data` (`GET /fapi/v1/indexPriceKlines`)
    - `kline-candlestick-data` (`GET /fapi/v1/klines`)
    - `mark-price-kline-candlestick-data` (`GET /fapi/v1/markPriceKlines`)
    - `premium-index-kline-data` (`GET /fapi/v1/premiumIndexKlines`)
- Modified parameter `limit`:
  - required: `true` → `false`
  - affected methods:
    - `basis` (`GET /futures/data/basis`)

**Spot**

### Added (1)

- `historical-block-trades` (`GET /api/v3/historicalBlockTrades`)

### Changed (1)

- Modified parameter `selfTradePreventionMode`:
  - enum added: `TRANSFER`
  - affected methods:
    - `new-order` (`POST /api/v3/order`)
    - `order-cancel-replace` (`POST /api/v3/order/cancelReplace`)
    - `order-oco` (`POST /api/v3/order/oco`)
    - `order-test` (`POST /api/v3/order/test`)
    - `order-list-oco` (`POST /api/v3/orderList/oco`)
    - `order-list-opo` (`POST /api/v3/orderList/opo`)
    - `order-list-opoco` (`POST /api/v3/orderList/opoco`)
    - `order-list-oto` (`POST /api/v3/orderList/oto`)
    - `order-list-otoco` (`POST /api/v3/orderList/otoco`)
    - `sor-order` (`POST /api/v3/sor/order`)
    - `sor-order-test` (`POST /api/v3/sor/order/test`)

**Sub Account**

### Changed (2)

- Added parameter `rows`
  - affected methods:
    - `get-move-position-history-for-sub-account` (`GET /sapi/v1/sub-account/futures/move-position`)
- Deleted parameter `row`
  - affected methods:
    - `get-move-position-history-for-sub-account` (`GET /sapi/v1/sub-account/futures/move-position`)

## 1.1.1 - 2026-04-13

### Updated

- Argument "--profile" takes precedence over env variables
- Validate profile name
- Use console.error for error messages

## 1.1.0 - 2026-04-11

### Added

- Added command to delete profile.

- Exit with error code on failed command.

- Added support for the following products:
    - Algo Trading
    - Alpha
    - C2C
    - Copy Trading
    - Crypto Loan
    - Derivatives Trading (COIN-M Futures)
    - Derivatives Trading (Options)
    - Derivatives Trading (Portfolio Margin)
    - Derivatives Trading (Portfolio Margin Pro)
    - Dual Investment
    - Fiat
    - Gift Card
    - Margin Trading
    - Mining
    - Pay
    - Rebate
    - Simple Earn
    - Staking
    - Sub Account
    - VIP Loan
    - Wallet

### Updated

- Add alias `profile select` for `profile change`
- Add option `--select` for `profile create` to select the profile after creation
- Add option `--force` for `profile create` to overwrite profile if existing

## 1.0.4 - 2026-04-09

### Updated

- Different User-Agent if used from AI Agent

## 1.0.3 - 2026-04-09

### Updated

- Simplified checks for required params

## 1.0.2 - 2026-04-09

### Added

- Add environment to profile commands

### Updated

- Add the request fields as options for POST/PUT endpoints
- Renamed `BINANCE_API_SECRET` to `BINANCE_SECRET_KEY`

## 1.0.1 - 2026-04-07

### Updated

- Accept json or list of params for POST/PUT endpoints

## 1.0.0 - 2026-04-07

- First release
